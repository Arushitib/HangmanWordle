package gui;

import java.awt.Color;
import java.util.HashMap;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import model.GameWordleSpinoff;
import javafx.scene.Scene;

import javafx.scene.layout.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class GameGUI extends Application {
	public static final String ANSI_RESET = "\u001B[0m";
	public static final String ANSI_YELLOW_BG = "\u001B[43m";
	public static final String ANSI_GREEN_BG = "\u001B[42m";
	public static final String ANSI_GREY_BG = "\u001B[47m";



	private TextField try1Text, try2Text, try3Text, try4Text, try5Text, try6Text;
	private TextField total1, total2, total3, total4, total5, total6;


	@Override /* Method in Application class */
	public void start(Stage primaryStage) throws Exception {

		int sceneWidth = 300, sceneHeight = 200;
		int verSpaceBetweenNodes = 8, horSpaceBetweenNodes = 8;
		int paneBorderTop = 20, paneBorderRight = 20;
		int paneBorderBottom = 20, paneBorderLeft = 20;

		/* Setting pane properties */
		GridPane pane = new GridPane();
		pane.setHgap(horSpaceBetweenNodes);
		pane.setVgap(verSpaceBetweenNodes);
		pane.setPadding(new Insets(paneBorderTop, paneBorderRight, paneBorderBottom, paneBorderLeft));

		/* Adding GUI elements to the pane */

		// 1st
		Button try1 = new Button("1st Try: ");
		try1Text = new TextField();
		pane.add(try1, 0, 0);
		pane.add(try1Text, 1, 0);

		Button button1 = new Button("Enter");
		pane.add(button1, 2, 0);
		button1.setOnAction(new ButtonHandler1());

		Button totalLabel1 = new Button("Feedback: ");
		total1 = new TextField();
		total1.setEditable(false); /* Cannot be changed */
		pane.add(totalLabel1, 3, 0);
		pane.add(total1, 4, 0);

		// 2nd
		Button try2 = new Button("2nd Try: ");
		try2Text = new TextField();
		pane.add(try2, 0, 1);
		pane.add(try2Text, 1, 1);

		Button button2 = new Button("Enter");
		pane.add(button2, 2, 1);
		button2.setOnAction(new ButtonHandler2());

		Button totalLabel2 = new Button("Feedback: ");
		total2 = new TextField();
		total2.setEditable(false); /* Cannot be changed */
		pane.add(totalLabel2, 3, 1);
		pane.add(total2, 4, 1);

		// 3rd
		Button try3 = new Button("3rd Try: ");
		try3Text = new TextField();
		pane.add(try3, 0, 2);
		pane.add(try3Text, 1, 2);

		Button button3 = new Button("Enter");
		pane.add(button3, 2, 2);
		button3.setOnAction(new ButtonHandler3());

		Button totalLabel3 = new Button("Feedback: ");
		total3 = new TextField();
		total3.setEditable(false); /* Cannot be changed */
		pane.add(totalLabel3, 3, 2);
		pane.add(total3, 4, 2);

		// 4th
		Button try4 = new Button("4th Try: ");
		try4Text = new TextField();
		pane.add(try4, 0, 3);
		pane.add(try4Text, 1, 3);

		Button button4 = new Button("Enter");
		pane.add(button4, 2, 3);
		button4.setOnAction(new ButtonHandler4());

		Button totalLabel4 = new Button("Feedback: ");
		total4 = new TextField();
		total4.setEditable(false); /* Cannot be changed */
		pane.add(totalLabel4, 3, 3);
		pane.add(total4, 4, 3);

		// 5th
		Button try5 = new Button("5th Try: ");
		try5Text = new TextField();
		pane.add(try5, 0, 4);
		pane.add(try5Text, 1, 4);

		Button button5 = new Button("Enter");
		pane.add(button5, 2, 4);
		button5.setOnAction(new ButtonHandler5());

		Button totalLabel5 = new Button("Feedback: ");
		total5 = new TextField();
		total5.setEditable(false); /* Cannot be changed */
		pane.add(totalLabel5, 3, 4);
		pane.add(total5, 4, 4);

		// 6th
		Button try6 = new Button("6th Try: ");
		try6Text = new TextField();
		pane.add(try6, 0, 5);
		pane.add(try6Text, 1, 5);

		Button button6 = new Button("Enter");
		pane.add(button6, 2, 5);
		button6.setOnAction(new ButtonHandler6());

		Button totalLabel6 = new Button("Feedback: ");
		total6 = new TextField();
		total6.setEditable(false); /* Cannot be changed */
		pane.add(totalLabel6, 3, 5);
		pane.add(total6, 4, 5);

		// setting scene
		Scene scene = new Scene(pane, sceneWidth, sceneHeight);

		primaryStage.setTitle("WELCOME TO \"HANGMAN - WORDLE\"");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	private class ButtonHandler1 implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent e) {
			String try1 = try1Text.getText().toUpperCase();
			try1 = GameWordleSpinoff.highlightUserAnswer(try1, GameWordleSpinoff.getQuesWordList(),
					GameWordleSpinoff.getLettersList());

			System.out.println("Text: " + try1);
			total1.setText(try1);
		}
	}

	private class ButtonHandler2 implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent e) {
			String try2 = try2Text.getText().toUpperCase();
			try2 = GameWordleSpinoff.highlightUserAnswer(try2, GameWordleSpinoff.getQuesWordList(),
					GameWordleSpinoff.getLettersList());
			System.out.println("Text: " + try2);
			total2.setText(try2);
		}
	}

	private class ButtonHandler3 implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent e) {
			String try3 = try3Text.getText().toUpperCase();
			try3 = GameWordleSpinoff.highlightUserAnswer(try3, GameWordleSpinoff.getQuesWordList(),
					GameWordleSpinoff.getLettersList());
			System.out.println("Text: " + try3);
			total3.setText(try3);
		}
	}

	private class ButtonHandler4 implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent e) {
			String try4 = try4Text.getText();
			try4 = GameWordleSpinoff.highlightUserAnswer(try4, GameWordleSpinoff.getQuesWordList(),
					GameWordleSpinoff.getLettersList());
			System.out.println("Text: " + try4);
			total4.setText(try4);
		}
	}

	private class ButtonHandler5 implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent e) {
			String try5 = try5Text.getText().toUpperCase();
			try5 = GameWordleSpinoff.highlightUserAnswer(try5, GameWordleSpinoff.getQuesWordList(),
					GameWordleSpinoff.getLettersList());
			System.out.println("Text: " + try5);
			total5.setText(try5);
		}
	}

	private class ButtonHandler6 implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent e) {
			String try6 = try6Text.getText();
			try6 = GameWordleSpinoff.highlightUserAnswer(try6, GameWordleSpinoff.getQuesWordList(),
					GameWordleSpinoff.getLettersList());
			System.out.println("Text: " + try6);
			total6.setText(try6);
		}
	}

	/*
	 * This method takes as input the payer's answer and the hashmap with the answer
	 * letters it then checks each word of the player's answer and highlights the
	 * letters that are in the correct position and letters that are in the answer
	 */
	public static String highlightUserAnswer(String playerAns, HashMap<Integer, String> quesWordList,
			HashMap<String, Integer> lettersList) {
		String ret = "";
		for (int i = 0; i < playerAns.length(); i++) {
			String curr = Character.toString(playerAns.charAt(i));
			if (curr.equals(quesWordList.get(i + 1)))
				ret += printGreenBG(curr);
			else if (lettersList.containsKey(curr) && (lettersList.get(curr) > 0)) {
				ret += printYellowBG(curr);
				lettersList.replace(curr, lettersList.get(curr) - 1);
			} else
				ret += printGreyBG(curr);
		}
		return ret;
	}

	

	/*
	 * This method returns input with Yellow highlight
	 */
	public static String printYellowBG(String input) {
		return ANSI_YELLOW_BG + input + ANSI_RESET;
	}

	/*
	 * This method returns input with Green highlight
	 */
	public static String printGreenBG(String input) {
		return ANSI_GREEN_BG + input + ANSI_RESET;
	}

	/*
	 * This method returns input with Grey highlight
	 */
	public static String printGreyBG(String input) {
		return ANSI_GREY_BG + input + ANSI_RESET;
	}

	public static void main(String[] args) {
		Application.launch(args);
	}
}
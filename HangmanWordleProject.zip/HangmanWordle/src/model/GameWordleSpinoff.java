package model;

import java.util.regex.Pattern;
import java.awt.Color;
import java.util.*;
import java.io.*;

public class GameWordleSpinoff {
	// a hashmap can be used to store the player's answers (i.e., the right letters)
	HashMap<Integer, String> answer = new HashMap<>();

	protected Random random;
	private int score; // score keeps track of no. of tries

	public static final String ANSI_RESET = "\u001B[0m";
	public static final String ANSI_YELLOW_BG = "\u001B[43m";
	public static final String ANSI_GREEN_BG = "\u001B[42m";
	public static final String ANSI_GREY_BG = "\u001B[47m";
	public static final String ANSI_RED_BG = "\u001B[41m";
	static HashMap<String, Integer> lettersList = new HashMap<>();
	static HashMap<Integer, String> quesWordList = new HashMap<>();

	/*
	 * here, generate a question, give user 6 tries, add correct/partials to the
	 * hashmap after each turn, display input with correct colors if at end of 6,
	 * wrong, then give answer if right, terminate turns and print congrats message
	 * make sure colors are printed correctly
	 */
	public static void main(String[] args) {
		boolean play = true;
		printInstructions();

		while (play) {
			Scanner scanner = new Scanner(System.in);

			/* map keeps track of letters in the question */
			quesWordList = new HashMap<>();

			String questionAnswer = "";
			String[] answer = generateWord();
			for (int i = 1; i <= answer.length; i++) {
				questionAnswer += answer[i - 1].toUpperCase();
				quesWordList.put(i, answer[i - 1]);
			}

			// taking input from player
			int countTries = 1;

			while (countTries <= 6) {
				lettersList = new HashMap<>();
				for (int i = 1; i <= answer.length; i++) {

					if (lettersList.containsKey(answer[i - 1])) {
						lettersList.replace(answer[i - 1], lettersList.get(answer[i - 1]) + 1);
					} else {
						lettersList.put(answer[i - 1], 1);
					}
				}
				if (countTries == 4) {
					generateHangmanPartOne();
				}
				if (countTries == 5) {
					generateHangmanPartTwo();
				}
				if (countTries == 6) {
					generateHangmanPartThree();
				}
				System.out.println("Enter answer for Try #" + countTries + " \n-> ");
				String playerAnswer = scanner.next();
				playerAnswer = playerAnswer.toUpperCase();
				if (playerAnswer.equals(questionAnswer)) {
					System.out.println(highlightUserAnswer(playerAnswer, quesWordList, lettersList));
					System.out.println("Congrats!!!");
					break;

				} else if (!Pattern.matches("^[a-zA-z]{5}$", playerAnswer)) {
					System.out.println("INVALID input provided. Please try again");

				} else {

					System.out.println("Try again! you have " + (6 - countTries) + " tries remaining\n-> ");
					System.out.println(highlightUserAnswer(playerAnswer, quesWordList, lettersList));
					countTries++;
				}
				if (countTries == 7) {
					System.out.println("CORRECT ANSWER: " + questionAnswer);
				}

			}

			System.out.println("Play again? y/n");
			String input = scanner.next();
			if (input.equals("Y") || input.equals("y")) {
				play = true;
			} else {
				play = false;
				return;
			}

			System.out.println("Do you want to go over the instructions again? y/n");
			input = scanner.next();
			if (input.equals("Y") || input.equals("y")) {
				printInstructions();
			}
		}
	}

	public static HashMap<String, Integer> getLettersList() {
		return lettersList;
	}

	public static HashMap<Integer, String> getQuesWordList() {
		return quesWordList;
	}

	/*
	 * This method takes as input the payer's answer and the hashmap with the answer
	 * letters it then checks each word of the player's answer and highlights the
	 * letters that are in the correct position and letters that are in the answer
	 */
	public static String highlightUserAnswer(String playerAns, HashMap<Integer, String> quesWordList,
			HashMap<String, Integer> lettersList) {
		String ret = "";
		for (int i = 0; i < playerAns.length(); i++) {
			String curr = Character.toString(playerAns.charAt(i));
			if (curr.equals(quesWordList.get(i + 1)))
				ret += printGreenBG(curr);
			else if (lettersList.containsKey(curr) && (lettersList.get(curr) > 0)) {
				ret += printYellowBG(curr);
				lettersList.replace(curr, lettersList.get(curr) - 1);
			} else
				ret += printRedBG(curr);
		}
		return ret;
	}

	/*
	 * This method should print the rules of the game
	 */
	public static void printInstructions() {
		System.out.println("---------- GAME RULES ----------");
		System.out.println("Hello there player!\n In this game, you will have six tries to guess "
				+ "a five-letter word.\n To help you out, each time you enter your guess, "
				+ "you will receive some feedback.\n Letters from your response in the correct spots "
				+ "will be highlighted in green,\n letters in the answer but not in the "
				+ "correct spots will be highlighted in yellow,\n and letters that don’t appear "
				+ "in the answer at all will be highlighted in red.\n Starting from the fourth guess, "
				+ "you will also be playing hangman;\n each time you guess incorrectly, "
				+ "more of the man will appear.\n Good luck guessing!\n And may the odds be ever in your favor :)");

		return;
	}

	/*
	 * This method returns input with Yellow highlight
	 */
	public static String printYellowBG(String input) {
		return ANSI_YELLOW_BG + input + ANSI_RESET;
	}

	/*
	 * This method returns input with Green highlight
	 */
	public static String printGreenBG(String input) {
		return ANSI_GREEN_BG + input + ANSI_RESET;
	}

	/*
	 * This method returns input with Grey highlight
	 */
	public static String printGreyBG(String input) {
		return ANSI_GREY_BG + input + ANSI_RESET;
	}

	/*
	 * This method returns input with Red highlight
	 */
	public static String printRedBG(String input) {
		return ANSI_RED_BG + input + ANSI_RESET;
	}

	/*
	 * This method stores all the words we plan to generate as questions for the
	 * game and generators a random number to generate a question
	 * 
	 */
	public static String[] generateWord() {
		Random rand = new Random();
		int random = rand.nextInt(50) + 1;
		//System.out.println(random);

		HashMap<Integer, String[]> map = new HashMap<>();

		String[] w1 = new String[] { "S", "T", "A", "I", "R" };
		map.put(1, w1);
		String[] w2 = new String[] { "L", "O", "F", "T", "Y" };
		map.put(2, w2);
		String[] w3 = new String[] { "Q", "U", "E", "E", "R" };
		map.put(3, w3);
		String[] w4 = new String[] { "S", "T", "E", "A", "D" };
		map.put(4, w4);
		String[] w5 = new String[] { "V", "O", "I", "C", "E" };
		map.put(5, w5);
		String[] w6 = new String[] { "S", "C", "R", "A", "P" };
		map.put(6, w6);
		String[] w7 = new String[] { "C", "L", "A", "S", "S" };
		map.put(7, w7);
		String[] w8 = new String[] { "F", "I", "E", "L", "D" };
		map.put(8, w8);
		String[] w9 = new String[] { "T", "H", "E", "M", "E" };
		map.put(9, w9);
		String[] w10 = new String[] { "I", "V", "O", "R", "Y" };
		map.put(10, w10);
		String[] w11 = new String[] { "W", "O", "V", "E", "N" };
		map.put(11, w11);
		String[] w12 = new String[] { "A", "G", "A", "P", "E" };
		map.put(12, w12);
		String[] w13 = new String[] { "M", "O", "I", "S", "T" };
		map.put(13, w13);
		String[] w14 = new String[] { "C", "R", "A", "S", "S" };
		map.put(14, w14);
		String[] w15 = new String[] { "D", "R", "O", "L", "L" };
		map.put(15, w15);
		String[] w16 = new String[] { "Y", "E", "I", "L", "D" };
		map.put(16, w16);
		String[] w17 = new String[] { "H", "U", "T", "C", "H" };
		map.put(17, w17);
		String[] w18 = new String[] { "G", "O", "O", "F", "Y" };
		map.put(18, w18);
		String[] w19 = new String[] { "U", "N", "F", "I", "T" };
		map.put(19, w19);
		String[] w20 = new String[] { "B", "L", "O", "W", "N" };
		map.put(20, w20);
		String[] w21 = new String[] { "A", "W", "F", "U", "L" };
		map.put(21, w21);
		String[] w22 = new String[] { "R", "O", "B", "O", "T" };
		map.put(22, w22);
		String[] w23 = new String[] { "F", "A", "V", "O", "R" };
		map.put(23, w23);
		String[] w24 = new String[] { "G", "L", "O", "A", "T" };
		map.put(24, w24);
		String[] w25 = new String[] { "F", "L", "U", "F", "F" };
		map.put(25, w25);
		String[] w26 = new String[] { "D", "E", "L", "V", "E" };
		map.put(26, w26);
		String[] w27 = new String[] { "H", "U", "M", "O", "R" };
		map.put(27, w27);
		String[] w28 = new String[] { "O", "X", "I", "D", "E" };
		map.put(28, w28);
		String[] w29 = new String[] { "Z", "E", "S", "T", "Y" };
		map.put(29, w29);
		String[] w30 = new String[] { "M", "I", "D", "S", "T" };
		map.put(30, w30);
		String[] w31 = new String[] { "B", "L", "A", "N", "K" };
		map.put(31, w31);
		String[] w32 = new String[] { "C", "Y", "N", "I", "C" };
		map.put(32, w32);
		String[] w33 = new String[] { "O", "T", "H", "E", "R" };
		map.put(33, w33);
		String[] w34 = new String[] { "U", "S", "I", "N", "G" };
		map.put(34, w34);
		String[] w35 = new String[] { "M", "O", "N", "E", "Y" };
		map.put(35, w35);
		String[] w36 = new String[] { "Q", "U", "I", "E", "T" };
		map.put(36, w36);
		String[] w37 = new String[] { "P", "E", "A", "K", "S" };
		map.put(37, w37);
		String[] w38 = new String[] { "L", "I", "G", "H", "T" };
		map.put(38, w38);
		String[] w39 = new String[] { "C", "R", "E", "A", "K" };
		map.put(39, w39);
		String[] w40 = new String[] { "K", "N", "E", "L", "L" };
		map.put(40, w40);
		String[] w41 = new String[] { "F", "R", "O", "N", "T" };
		map.put(41, w41);
		String[] w42 = new String[] { "B", "R", "I", "N", "G" };
		map.put(42, w42);
		String[] w43 = new String[] { "S", "T", "O", "R", "Y" };
		map.put(43, w43);
		String[] w44 = new String[] { "M", "O", "V", "I", "E" };
		map.put(44, w44);
		String[] w45 = new String[] { "B", "A", "N", "A", "L" };
		map.put(45, w45);
		String[] w46 = new String[] { "A", "S", "K", "E", "W" };
		map.put(46, w46);
		String[] w47 = new String[] { "T", "A", "C", "I", "T" };
		map.put(47, w47);
		String[] w48 = new String[] { "D", "O", "Z", "E", "N" };
		map.put(48, w48);
		String[] w49 = new String[] { "C", "O", "M", "I", "C" };
		map.put(49, w49);
		String[] w50 = new String[] { "F", "L", "A", "I", "R" };
		map.put(50, w50);

		String[] question = map.get(random);
		return question;

	}

	/*
	 * Generates the first segment of the hangman
	 */
	public static void generateHangmanPartOne() {
		System.out.println("_________");
		System.out.println(" |");
		System.out.println(" |");
		System.out.println(" |");
		System.out.println(" |");
		System.out.println(" |");
		System.out.println("_|_ ");
	}

	/*
	 * Generates the second segment of the hangman
	 */
	public static void generateHangmanPartTwo() {
		System.out.println("_________");
		System.out.println(" |      |");
		System.out.println(" |      O");
		System.out.println(" |");
		System.out.println(" |");
		System.out.println(" |");
		System.out.println("_|_ ");
	}

	/*
	 * Generates the third segment of the hangman
	 */
	public static void generateHangmanPartThree() {
		System.out.println("__________");
		System.out.println(" |       |");
		System.out.println(" |       O");
		System.out.println(" |      \\|/");
		System.out.println(" |       |");
		System.out.println(" |      / \\");
		System.out.println("_|_ ");
	}

}

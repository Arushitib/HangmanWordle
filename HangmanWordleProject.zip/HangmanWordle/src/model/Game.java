package model;


public abstract class Game {
	
	protected int maxRows = 6;
	protected int maxCols = 5;

	/**
	 * Defines a board with BoardCell.EMPTY cells.
	 * 
	 * @param maxRows
	 * @param maxCols
	 */

	public Game(int maxRows, int maxCols) {
		this.maxCols = maxCols;
		this.maxRows = maxRows;
		
	}

	public int getMaxRows() {
		return maxRows;
	}

	public int getMaxCols() {
		return maxCols;
	}

	/**
	 * Sets the board to blanks
	 * 
	 * @param rowIndex
	 * @param colIndex
	 */
	public void setBoard(int maxRows, int maxCols) {
		
	}

	public abstract boolean isGameOver();

	public abstract int getScore();

	/**
	 * Adjust the board state according to the current board state and the selected
	 * cell.
	 * 
	 * @param rowIndex
	 * @param colIndex
	 */


}
